create database curate;
create schema final;

create or replace table curate.final.customers
(ID NUMBER,
 FIRST_NAME varchar,
 LAST_NAME VARCHAR,
 JOB_TITLE VARCHAR,
 DEPARTMENT VARCHAR,
 PHONE_NUM VARCHAR, 
 ADDRESS variant,
 REC_CREATED_ON TIMESTAMP
)
;

select * from curate.final.customers;

/*
2. Remove some columns (username)
3. strip data from lastName (remove _,/,.)
4. standardize phone numbers (format is 1234567891)
        (If the number is greater than 10, remove the numbers at the right end)
        (If the number length is less than 10, add 0s at the right end)
5. Split city and state 
6. Pull only the values from adress column
*/

insert into curate.final.customers
select  c.rawcol:Id::int as id,c.rawcol:Firstname::varchar as firstname,
        regexp_replace(c.rawcol:Lastname::string, '[^a-zA-Z\-]', '') as lastname,
        c.rawcol:Jobtitle::string jobtitle,c.rawcol:Department::string department,
        rpad(regexp_replace(c.rawcol:Contact[1]::string,'[^0-9]',''),10,0) as phonenum,
        c.rawcol:Address as address,current_timestamp
from    
        raw.source.raw_customers as c
where 
        rec_created_on = (select max(max_date) from raw.source.max_timestamp)
order by 1
;

select * from curate.final.customers;

truncate table curate.final.customers;



create or replace task task_curate_load
schedule = 'USING CRON 0 0 * * * UTC'
as
insert into curate.final.customers
select  c.rawcol:Id::int as id,c.rawcol:Firstname::varchar as firstname,
        regexp_replace(c.rawcol:Lastname::string, '[^a-zA-Z\-]', '') as lastname,
        c.rawcol:Jobtitle::string jobtitle,c.rawcol:Department::string department,
        rpad(regexp_replace(c.rawcol:Contact[1]::string,'[^0-9]',''),10,0) as phonenum,
        c.rawcol:Address as address,current_timestamp
from    
        raw.source.raw_customers as c
where 
        rec_created_on = (select max(max_date) from raw.source.max_timestamp)
order by 1
;

show tasks;

ALTER task task_curate_load suspend;