show parameters like 'TIMEZONE%';
Alter account set TIMEZONE = 'Asia/Kolkata';

create or replace database raw;
create or replace schema source;

--create a stage
create or replace stage raw.source.customers_stage;

--list the files from the stage
ls @raw.source.customers_stage;
--add file to a stage

--create a file format to handle JSON
create or replace file format raw.source.ff_json
type = 'json'
STRIP_OUTER_ARRAY = TRUE
;

show file formats;


--create a raw table that saves the actual data as it is
CREATE OR REPLACE TABLE raw.source.raw_customers 
(rawcol variant,
filename varchar,
rec_created_on timestamp
)
;


--querying data from the file
select $1,metadata$filename
from @customers_stage
(file_format => 'ff_json')
;



copy into raw.source.raw_customers
from
(select $1,metadata$filename,current_timestamp
from @customers_stage
(file_format => 'ff_json'))
;

truncate table raw.source.raw_customers;

select * from raw.source.raw_customers;




------------------------ Saving the maximum timestamp in a table to insert only the lastest batch records in the curate table
select max(rec_created_on) from raw.source.raw_customers;

create or replace table raw.source.max_timestamp
(max_date timestamp)
;

insert into raw.source.max_timestamp
select max(rec_created_on) from raw.source.raw_customers;

select * from raw.source.max_timestamp;





-- select * from stream_customers;

























/*
1. Removing duplicates
2. Remove some columns (username)
3. strip data from lastName (remove _,/,.)
4. standardize phone numbers (format is 123-456-7891) (If there are extra numbers, remove the numbers at the right end)
5. Split city and state 
6. Pull only the values from adress column
*/
select  c.rawcol:Id::int as id,c.rawcol:Firstname::varchar as firstname,
        regexp_replace(c.rawcol:Lastname::string, '[^a-zA-Z\-]', '') as lastname,
        c.rawcol:Jobtitle::string jobtitle,c.rawcol:Department::string department,
        --c.rawcol:Contact[1]::string,
        rpad(regexp_replace(c.rawcol:Contact[1]::string,'[^0-9]',''),10,0) as contact,
        substr(contact,1,3) || '-' || substr(contact,4,3) || '-' || substr(contact,7,4) as contact_actual,
        c.rawcol:Address as address,
       listagg(fl.value::string,',') as Actual_address
from raw.source.customers as c,
     table(flatten(Input => c.rawcol:Address)) as fl
     group by 1,2,3,4,5,6,7,8
     order by 1
;





SELECT *
FROM TABLE(FLATTEN(INPUT => PARSE_JSON('{"A":1, "B":[77,88]}'),PATH => 'B'));
 
SELECT *
FROM TABLE(FLATTEN(INPUT => PARSE_JSON('{"A":1, "B":[77,88],"C":[22,33]}')));
 
SELECT *
FROM TABLE(FLATTEN(INPUT => PARSE_JSON('{"A":1, "B":[77,88],"C":[22,33]}'),recursive => True));